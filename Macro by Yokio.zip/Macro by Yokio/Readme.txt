import keyboard
import time

def press_space(interval):
    while True:
        keyboard.press('e')--tecla
        time.sleep(interval)
        keyboard.release('e')---tecla
        time.sleep(interval)

press_space(0.1)
